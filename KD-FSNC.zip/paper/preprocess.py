from torch_geometric.datasets import Planetoid, Amazon, Coauthor, CoraFull
import random
import torch

def load_data(arg):
    dname = arg.dataset
    if dname == 'Cora':
        dataset = Planetoid(name='Cora',root='./data')
    elif dname == 'CiteSeer':
        dataset = Planetoid(name='CiteSeer',root='./data')
    elif dname == 'cs':
        dataset = Coauthor(name='cs',root='./data')
    elif dname == 'Computers':
        dataset = Amazon(name='Computers',root='./data')
    elif dname == 'Photo':
        dataset = Amazon(name='Photo',root='./data')
    elif dname == 'CoraFull':
        dataset =  CoraFull(root='./data')
    else:
        return None
    return dataset

def get_class_num(arg):
    dataset = load_data(arg)
    return dataset.num_classes

def get_index2_mtrain(arg,labels,train_classes):
    ## 取出meta-learning 中测试集的类别
    class1_idx = []
    class2_idx = []

    # 取出类别的index
    for i in range(len(labels)):
        if (labels[i] == train_classes[0]):
            class1_idx.append(i)
            labels[i] = 0
        elif (labels[i] == train_classes[1]):
            class2_idx.append(i)
            labels[i] = 1

    # 随机抽取 support set 和 query set
    class1_spt = random.sample(class1_idx, len(class1_idx)-12)
    class2_spt = random.sample(class2_idx, len(class2_idx)-12)

    class1_qry = [n1 for n1 in class1_idx if n1 not in class1_spt]
    class2_qry = [n2 for n2 in class2_idx if n2 not in class2_spt]

    class1_qry = random.sample(class1_qry, arg.qry_num)
    class2_qry = random.sample(class2_qry, arg.qry_num)

    spt_idx = class1_spt + class2_spt
    qry_idx = class1_qry + class2_qry
    random.shuffle(spt_idx)
    random.shuffle(qry_idx)

    all_classes = class1_idx + class2_idx

    spt_idx_list = [class1_spt,class2_spt]

    return all_classes,spt_idx,qry_idx,spt_idx_list

def get_index5_mtrain(arg,labels,train_classes):
    ## 取出meta-learning 中测试集的类别
    class1_idx = []
    class2_idx = []
    class3_idx = []
    class4_idx = []
    class5_idx = []

    # 取出类别的index
    for i in range(len(labels)):
        if (labels[i] == train_classes[0]):
            class1_idx.append(i)
            labels[i] = 0
        elif (labels[i] == train_classes[1]):
            class2_idx.append(i)
            labels[i] = 1
        elif (labels[i] == train_classes[2]):
            class3_idx.append(i)
            labels[i] = 2
        elif (labels[i] == train_classes[3]):
            class4_idx.append(i)
            labels[i] = 3
        elif (labels[i] == train_classes[4]):
            class5_idx.append(i)
            labels[i] = 4

    # 随机抽取 support set 和 query set
    class1_spt = random.sample(class1_idx, len(class1_idx)-12)
    class2_spt = random.sample(class2_idx, len(class2_idx)-12)
    class3_spt = random.sample(class3_idx, len(class3_idx)-12)
    class4_spt = random.sample(class4_idx, len(class4_idx)-12)
    class5_spt = random.sample(class5_idx, len(class5_idx)-12)

    class1_qry = [n1 for n1 in class1_idx if n1 not in class1_spt]
    class2_qry = [n2 for n2 in class2_idx if n2 not in class2_spt]
    class3_qry = [n3 for n3 in class3_idx if n3 not in class3_spt]
    class4_qry = [n4 for n4 in class4_idx if n4 not in class4_spt]
    class5_qry = [n5 for n5 in class5_idx if n5 not in class5_spt]

    class1_qry = random.sample(class1_qry, arg.qry_num)
    class2_qry = random.sample(class2_qry, arg.qry_num)
    class3_qry = random.sample(class3_qry, arg.qry_num)
    class4_qry = random.sample(class4_qry, arg.qry_num)
    class5_qry = random.sample(class5_qry, arg.qry_num)

    spt_idx = class1_spt + class2_spt + class3_spt + class4_spt + class5_spt
    qry_idx = class1_qry + class2_qry + class3_qry + class4_qry + class5_qry
    random.shuffle(spt_idx)
    random.shuffle(qry_idx)

    all_classes = class1_idx + class2_idx + class3_idx + class4_idx + class5_idx

    spt_idx_list = [class1_spt,class2_spt,class3_spt,class4_spt,class5_spt]

    return all_classes,spt_idx,qry_idx,spt_idx_list

def get_index2_mtest(arg,labels,train_classes):
    ## 取出meta-learning 中测试集的类别
    class1_idx = []
    class2_idx = []

    # 取出类别的index
    for i in range(len(labels)):
        if (labels[i] == train_classes[0]):
            class1_idx.append(i)
            labels[i] = 0
        elif (labels[i] == train_classes[1]):
            class2_idx.append(i)
            labels[i] = 1

    # 随机抽取 support set 和 query set
    class1_spt = random.sample(class1_idx, arg.spt_num)
    class2_spt = random.sample(class2_idx, arg.spt_num)

    class1_qry = [n1 for n1 in class1_idx if n1 not in class1_spt]
    class2_qry = [n2 for n2 in class2_idx if n2 not in class2_spt]

    class1_qry = random.sample(class1_qry, arg.qry_num)
    class2_qry = random.sample(class2_qry, arg.qry_num)

    spt_idx = class1_spt + class2_spt
    qry_idx = class1_qry + class2_qry
    random.shuffle(spt_idx)
    random.shuffle(qry_idx)

    all_classes = class1_idx + class2_idx

    spt_idx_list = [class1_spt,class2_spt]

    return all_classes,spt_idx,qry_idx,spt_idx_list

def get_index5_mtest(arg,labels,train_classes):
    ## 取出meta-learning 中测试集的类别
    class1_idx = []
    class2_idx = []
    class3_idx = []
    class4_idx = []
    class5_idx = []

    # 取出类别的index
    for i in range(len(labels)):
        if (labels[i] == train_classes[0]):
            class1_idx.append(i)
            labels[i] = 0
        elif (labels[i] == train_classes[1]):
            class2_idx.append(i)
            labels[i] = 1
        elif (labels[i] == train_classes[2]):
            class3_idx.append(i)
            labels[i] = 2
        elif (labels[i] == train_classes[3]):
            class4_idx.append(i)
            labels[i] = 3
        elif (labels[i] == train_classes[4]):
            class5_idx.append(i)
            labels[i] = 4

    # 随机抽取 support set 和 query set
    class1_spt = random.sample(class1_idx, arg.spt_num)
    class2_spt = random.sample(class2_idx, arg.spt_num)
    class3_spt = random.sample(class3_idx, arg.spt_num)
    class4_spt = random.sample(class4_idx, arg.spt_num)
    class5_spt = random.sample(class5_idx, arg.spt_num)

    class1_qry = [n1 for n1 in class1_idx if n1 not in class1_spt]
    class2_qry = [n2 for n2 in class2_idx if n2 not in class2_spt]
    class3_qry = [n3 for n3 in class3_idx if n3 not in class3_spt]
    class4_qry = [n4 for n4 in class4_idx if n4 not in class4_spt]
    class5_qry = [n5 for n5 in class5_idx if n5 not in class5_spt]

    class1_qry = random.sample(class1_qry, arg.qry_num)
    class2_qry = random.sample(class2_qry, arg.qry_num)
    class3_qry = random.sample(class3_qry, arg.qry_num)
    class4_qry = random.sample(class4_qry, arg.qry_num)
    class5_qry = random.sample(class5_qry, arg.qry_num)

    spt_idx = class1_spt + class2_spt + class3_spt + class4_spt + class5_spt
    qry_idx = class1_qry + class2_qry + class3_qry + class4_qry + class5_qry
    random.shuffle(spt_idx)
    random.shuffle(qry_idx)

    all_classes = class1_idx + class2_idx + class3_idx + class4_idx + class5_idx

    spt_idx_list = [class1_spt,class2_spt,class3_spt,class4_spt,class5_spt]

    return all_classes,spt_idx,qry_idx,spt_idx_list

def metatrain_split(arg, train_classes):
    dataset = load_data(arg)
    in_dim = dataset.num_features

    data = dataset[0].to(arg.device)
    node_num = len(data.y)
    labels = (data.y).clone().detach()

    if arg.test_num == 2:
        all_classes,spt_idx,qry_idx,spt_idx_list = get_index2_mtrain(arg,labels,train_classes)
    elif arg.test_num == 5:
        all_classes,spt_idx,qry_idx,spt_idx_list = get_index5_mtrain(arg,labels,train_classes)
    else:
        pass

    # mask of train and test
    train_mask = torch.zeros(node_num, dtype=torch.bool)
    for i in range(len(spt_idx)):
        train_mask[spt_idx[i]] = 1

    test_mask = torch.zeros(node_num, dtype=torch.bool)
    for i in range(len(qry_idx)):
        test_mask[qry_idx[i]] = 1

    return data, train_mask, test_mask, labels, in_dim


def metatest_split(arg, test_classes):
    dataset = load_data(arg)
    in_dim = dataset.num_features

    data = dataset[0].to(arg.device)
    node_num = len(data.y)
    labels = (data.y).clone().detach()

    if arg.test_num == 2:
        all_classes, spt_idx,qry_idx,spt_idx_list = get_index2_mtest(arg,labels,test_classes)
    elif arg.test_num == 5:
        all_classes, spt_idx,qry_idx,spt_idx_list = get_index5_mtest(arg,labels,test_classes)
    else:
        pass    

    return data, spt_idx_list, all_classes, spt_idx, qry_idx, labels, in_dim
