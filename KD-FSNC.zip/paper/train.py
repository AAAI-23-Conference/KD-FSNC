from multiprocessing import reduction
from network import *
from preprocess import *
from torch_geometric.utils import to_dense_adj,subgraph,remove_isolated_nodes
from torch_geometric.data import Data
import random
import warnings
warnings.filterwarnings("ignore")

## teacher training
def metatrain_train(arg, train_classes):
    data, train_mask, test_mask, labels, in_dim = metatrain_split(arg, train_classes)
    model = Net(in_dim,arg.test_num).to(arg.device)
    optimizer1 = torch.optim.Adam([
        {'params': model.conv1.parameters()},
        {'params': model.conv2.parameters()},
        {'params': model.classifier.parameters()}], lr=arg.opti1_lr, weight_decay=5e-4)

    model.train()
    for epoch in range(arg.epoch):
        optimizer1.zero_grad()
        out = model.forward(data)
        loss = F.nll_loss(out[train_mask], labels[train_mask])
        loss.backward()
        optimizer1.step()

    # 提取全部节点的 node embeding
    node_embeding = model.embeding(data)
    node_embeding = node_embeding.detach()  # 去掉梯度

    node_second_embeding = model.second_embeding(data)
    node_second_embeding = node_second_embeding.detach()  # 去掉梯度
    conv1_weight = model.conv1.lin.weight  # 传递第一层参数

    return conv1_weight, node_embeding, node_second_embeding


## student training
def metatest_train(arg, test_classes, conv1_weight, teacher_embedding, teacher_second_embedding):
    data, spt_idx_list, all_class, spt_idx, qry_idx, labels, in_dim = metatest_split(arg, test_classes)
    model = Net2(in_dim,arg.test_num).to(arg.device)
    node_num = len(data.y)

    model.conv1.lin.weight = conv1_weight   # 初始化先验知识的参数
    optimizer1 = torch.optim.Adam([
        {'params': model.conv1.parameters()},
        {'params': model.conv2.parameters()},
        {'params': model.classifier.parameters()}], lr=arg.opti1_lr, weight_decay=5e-4)



    # Use support set to update
    train_mask = torch.zeros(node_num, dtype=torch.bool)
    for i in range(len(spt_idx)):
        train_mask[spt_idx[i]] = 1

    model.train()
    for epoch in range(arg.epoch):
        optimizer1.zero_grad()
        out = model.forward(data)
        loss = F.nll_loss(out[train_mask], labels[train_mask])
        loss.backward()
        optimizer1.step()








    # ------------------------- self-traing--------------------------
    for selftrain in range(arg.selftrain_cir):

        # mask of train and pseudo-label
        train_mask = torch.zeros(node_num, dtype=torch.bool)
        for i in range(len(spt_idx)):
            train_mask[spt_idx[i]] = 1

        pseudo_mask = torch.zeros(node_num, dtype=torch.bool)

        all_idx = spt_idx + qry_idx  # 伪标签节点不能是spt+qry
        new_x = model.confidence(data)
        new_x = new_x[all_class, :]
        pseudo_idx = []  # 伪标签的索引

        labels_mx = []  # 存放每个label的排序后的样本矩阵
        labels_dis = []  # 最终提取出的各个label的样本
        pselabel_num = 0  # 伪标签总数，因为如果固定10个，而训练出判断为该类的不足10个的话，生成噪声会报错

        ## 取出每个label信息熵低的Top-k个
        for i in range(arg.test_num):
            mx = new_x[new_x[:, -1] == i, :]  # 提取
            labels_mx.append(mx[mx[:, -2].argsort()])  # 排序

        for i in range(arg.test_num):
            label_num = []  # 伪标签节点对应的index，不能是 spt和que里面的值
            for j in range(labels_mx[i].shape[0]):
                if int(labels_mx[i][j, 0]) not in all_idx:
                    label_num.append(j)
                if len(label_num) == arg.selftrain_num:
                    break

            pselabel_num += len(label_num)
            # number, pseudo-label
            labels_dis.append(labels_mx[i][label_num, :][:, [0, 2]])

        ## 给置信度高的 node 打上伪标签
        for i in range(arg.test_num):
            for j in range(labels_dis[i].shape[0]):
                # 在label上打上伪标签
                labels[int(labels_dis[i][j, 0])] = int(labels_dis[i][j, 1])

                # 在训练集 mask 打上伪标签的index
                pseudo_mask[int(labels_dis[i][j, 0])] = 1
                spt_idx.append(int(labels_dis[i][j, 0]))
                pseudo_idx.append(int(labels_dis[i][j, 0]))

        ##############################################
        nway = len(spt_idx_list)
        prototype = []
        for i in range(nway):
            prototype.append(torch.mean(teacher_embedding[spt_idx_list[i],], dim=0))

        teacher_pseudo = teacher_embedding[pseudo_idx,]
        distance = torch.zeros([len(pseudo_idx), nway])

        for z in range(len(pseudo_idx)):
            for i in range(nway):
                vector = teacher_pseudo[z,] - prototype[i]
                pronorm = torch.norm(vector, p=2)
                distance[z, i] = (-pronorm)
        ##############################################

        # Pseudo distillation setting
        # prototype_1 = torch.mean(teacher_embedding[class1_spt,], dim=0)
        # prototype_2 = torch.mean(teacher_embedding[class2_spt,], dim=0)

        # teacher_pseudo = teacher_embedding[pseudo_idx,]
        # distance = torch.zeros([len(pseudo_idx), 2])
        # for z in range(len(pseudo_idx)):
        #     vector1 = teacher_pseudo[z,] - prototype_1
        #     vector2 = teacher_pseudo[z,] - prototype_2
        #     pronorm1 = torch.norm(vector1, p=2)
        #     pronorm2 = torch.norm(vector2, p=2)
        #     distance[z, 0] = (-pronorm1)
        #     distance[z, 1] = (-pronorm2)



        # Support set and pseudo-label set


        sub_node_num = int(max(0.1 * node_num, 1000))        #子图结点数

        for epoch in range(arg.epoch):
            optimizer1.zero_grad()


            ##### sample subgraph ==>
            sub_graph_index = random.sample([i for i in range(node_num)],sub_node_num)  #子图结点索引

            #子图索引映射至连续值
            sub_graph_index,index_of_index = torch.unique(torch.LongTensor(sub_graph_index),return_inverse=True)
            sub_graph_index = sub_graph_index.tolist()
            index_of_index = index_of_index.tolist()
            index_map = {}
            for i in range(len(sub_graph_index)):
                index_map[sub_graph_index[i]] = index_of_index[i]

            sub_x = data.x[sub_graph_index]         #子图所有结点
            #获取子图的邻居关系
            sub_edge_index,sub_edge_attr = subgraph(sub_graph_index,edge_index=data.edge_index,edge_attr=data.edge_attr)
            sub_edge_index = sub_edge_index.tolist()

            #子图邻居关系映射至连续值
            for i in range(len(sub_edge_index[0])):
                sub_edge_index[0][i] = index_map[sub_edge_index[0][i]]
                sub_edge_index[1][i] = index_map[sub_edge_index[1][i]]

            #移除孤立边
            edge_index,edge_attr,node_mask = remove_isolated_nodes(torch.LongTensor(sub_edge_index),num_nodes=sub_node_num)
            # sub_x = sub_x[node_mask]
            # sb_graph = Data(x=sub_x,edge_index=edge_index,edge_attr=edge_attr)
            ##### sample subgraph <==

            # -------------- embedding dis ----------------
            #--- frist layer ---
            namuda = 0.1
            sigma = 1
            ### global constraint
            student_embedding = model.embeding(data)
            globle_loss = F.mse_loss(student_embedding, teacher_embedding, reduction='mean')

            ### local constraint
            sub_teacher_embedding = teacher_embedding[sub_graph_index][node_mask]
            sub_student_embedding = student_embedding[sub_graph_index][node_mask]

            teacher_distences = F.mse_loss(sub_teacher_embedding.unsqueeze(dim=1), sub_teacher_embedding, reduction='none')
            teacher_distences.detach()
            teacher_distences = teacher_distences.sum(dim=2) / (sigma ** 2)
            distence_coefficient = teacher_distences.negative().exp()
            dense_adj = to_dense_adj(edge_index).squeeze(0).to(arg.device)
            masked_distence_coefficient = distence_coefficient.mul(dense_adj)

            student_distences = F.mse_loss(sub_student_embedding.unsqueeze(dim=1), sub_student_embedding, reduction='none')
            student_distences = student_distences.sum(dim=2)
            masked_student_distences = student_distences.mul(dense_adj)
            masked_student_distences = masked_student_distences.mul(masked_distence_coefficient)
            local_loss = masked_student_distences.mean()
            loss_distillation1 = namuda * globle_loss + (1 - namuda) * local_loss





            # --- second layer ---
            namuda = 0.1
            sigma = 1
            ### global constraint
            student_second_embedding = model.second_embeding(data)
            globle_loss = F.mse_loss(student_second_embedding, teacher_second_embedding, reduction='mean')

            ### local constraint
            sub_teacher_second_embedding = teacher_second_embedding[sub_graph_index][node_mask]
            sub_student_second_embedding = student_second_embedding[sub_graph_index][node_mask]

            teacher_distences = F.mse_loss(sub_teacher_second_embedding.unsqueeze(dim=1), sub_teacher_second_embedding, reduction='none')
            teacher_distences.detach()
            teacher_distences = teacher_distences.sum(dim=2) / (sigma ** 2)
            distence_coefficient = teacher_distences.negative().exp()
            dense_adj = to_dense_adj(edge_index).squeeze(0).to(arg.device)
            masked_distence_coefficient = distence_coefficient.mul(dense_adj)

            student_distences = F.mse_loss(sub_student_second_embedding.unsqueeze(dim=1), sub_student_second_embedding, reduction='none')
            student_distences = student_distences.sum(dim=2)
            masked_student_distences = student_distences.mul(dense_adj)
            masked_student_distences = masked_student_distences.mul(masked_distence_coefficient)
            local_loss = masked_student_distences.mean()
            loss_distillation2 = namuda * globle_loss + (1 - namuda) * local_loss

            loss_distillation = loss_distillation1 + loss_distillation2
            # ------------------------



            out = model.forward(data)
            loss_train = F.nll_loss(out[train_mask], labels[train_mask])
            loss_pseudo = F.nll_loss(out[pseudo_mask], labels[pseudo_mask])

            # Pseudo-labels distillation
            out1 = model.casoft(data)
            softloss = nn.KLDivLoss(reduction="batchmean")
            loss_softpseudo = softloss((F.log_softmax(out1 / arg.T, dim=1))[pseudo_mask],
                                       F.softmax(distance / arg.T, dim=1).to(arg.device))

            loss = loss_train + (0.9*loss_pseudo + 0.1*loss_softpseudo) + 0.3*loss_distillation

            loss.backward()
            optimizer1.step()

    # ----------------------------------------------------------












    ## test
    # mask of test
    test_mask = torch.zeros(node_num, dtype=torch.bool)
    for i in range(len(qry_idx)):
        test_mask[qry_idx[i]] = 1

    node_embeding = model.embeding(data)
    node_embeding = node_embeding.detach()  # 去掉梯度
    model.eval()
    _, pred = model.classify(node_embeding).max(dim=1)
    correct = int(pred[test_mask].eq(labels[test_mask]).sum().item())
    acc = correct / int(test_mask.sum())
    print('Accuracy: {:.4f}'.format(acc))

    return acc