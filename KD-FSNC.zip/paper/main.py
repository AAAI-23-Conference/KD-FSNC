import random
import argparse
from preprocess import *
from train import *
import numpy as np
import time

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

def arg_parse():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    parser = argparse.ArgumentParser(description='FewGraph arguments.')
    parser.add_argument('--spt_num', type=int, help='supprt set number')
    parser.add_argument('--qry_num', type=int, help='query set number')
    parser.add_argument('--selftrain_num', type=int, help='Pseudo-label node number')
    parser.add_argument('--epoch', type=int, help='epoch')
    parser.add_argument('--selftrain_cir', type=int, help='selftraining cir')
    parser.add_argument('--class_num', type=int, help='class num')
    parser.add_argument('--test_num', type=int, help='test num')
    parser.add_argument('--opti1_lr', type=float, help='conv1 + conv2 + classifier')
    parser.add_argument('--T', type=int, help='temperature')
    parser.add_argument('--device', type=str, help='cuda or cpu')
    parser.add_argument('--dataset', type=str,default='Cora', help='Cora/CiteSeer/cs/Computers/Photo')

    parser.set_defaults(spt_num = 1,
                        qry_num = 12,
                        selftrain_num = 40,
                        epoch = 100,
                        selftrain_cir = 3,
                        class_num = 7,
                        test_num = 2,
                        opti1_lr = 0.01,
                        T = 10000,
                        device = device
                       )
    return parser.parse_args()

if __name__ == '__main__':
    start = time.time()
    arg = arg_parse()
    class_num = get_class_num(arg)
    all_classes = list(range(class_num))

    # all_classes = list(range(arg.class_num))
    results = []

    for i in range(1):
        print("meta train:")
        print("{}-th division: ".format(i+1))
        random.seed(i)
        test_classes = random.sample(all_classes, arg.test_num)
        train_classes = [a1 for a1 in all_classes if a1 not in test_classes]
        train_classes = random.sample(train_classes, arg.test_num)

        # meta_train
        conv1_weight, teacher_embedding, teacher_second_embedding = metatrain_train(arg, train_classes)

        # 同一个数据划分下的10次随机种子
        print("meta test:")
        for seed in range(100, 102):
            # meta_test
            setup_seed(seed)
            result = metatest_train(arg, test_classes, conv1_weight, teacher_embedding, teacher_second_embedding)
            results.append(result)

    print(np.mean(results))
    print(np.var(results))

    end = time.time()
    print("该程序运行的总时间:",round(end-start,2),"秒")
    print("该程序运行的总时间:",round((end-start)/60,2),"分")
